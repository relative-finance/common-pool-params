# common-pool-params

A simple lambda function which returns params required for common pool API. We can use this param API as an easier point of access for updating global settings rather than having to change these settings within the common pool API itself.
